// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_INTERNAL_NOEXCEPT_ACTION_H
#define GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_INTERNAL_NOEXCEPT_ACTION_H

#include "google/cloud/version.h"
#include "absl/functional/function_ref.h"
#include <optional>

namespace google {
namespace cloud {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace internal {

/**
 * Execute an action that can throw in a noexcept context.
 *
 * Returns true if the action was successful (i.e. it did not throw). Returns
 * false if the action throws.
 */
bool NoExceptAction(absl::FunctionRef<void()> action) noexcept;

/**
 * Execute an action that can throw in a noexcept context.
 *
 * Returns the result of the action, if it was successful (i.e. it did not
 * throw). Returns std::nullopt if the action throws.
 */
template <typename T>
#if GOOGLE_CLOUD_CPP_HAVE_EXCEPTIONS
std::optional<T> NoExceptAction(absl::FunctionRef<T()> action) noexcept try {
  return action();
} catch (...) {
  return std::nullopt;
}
#else
std::optional<T> NoExceptAction(absl::FunctionRef<T()> action) noexcept {
  // If this crashes, it would have crashed anyway.
  return action();
}
#endif

}  // namespace internal
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace cloud
}  // namespace google

#endif  // GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_INTERNAL_NOEXCEPT_ACTION_H
