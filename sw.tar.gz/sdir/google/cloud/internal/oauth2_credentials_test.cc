// Copyright 2022 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/internal/oauth2_credentials.h"
#include "google/cloud/internal/make_status.h"
#include "google/cloud/testing_util/status_matchers.h"
#include <gmock/gmock.h>

namespace google {
namespace cloud {
namespace oauth2_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

using ::google::cloud::internal::UnavailableError;
using ::google::cloud::testing_util::IsOk;
using ::google::cloud::testing_util::IsOkAndHolds;
using ::testing::Contains;
using ::testing::Not;
using ::testing::Return;

class MockCredentials : public Credentials {
 public:
  MOCK_METHOD(StatusOr<AccessToken>, GetToken,
              (std::chrono::system_clock::time_point), (override));
  MOCK_METHOD(StatusOr<rest_internal::HttpHeader>, AllowedLocations,
              (std::chrono::system_clock::time_point, std::string_view),
              (override));
};

TEST(Credentials, AuthorizationHeaderSuccess) {
  MockCredentials mock;
  auto const now = std::chrono::system_clock::now();
  auto const expiration = now + std::chrono::seconds(3600);
  EXPECT_CALL(mock, GetToken(now))
      .WillOnce(Return(AccessToken{"test-token", expiration}));
  EXPECT_CALL(mock, AllowedLocations)
      .WillOnce(Return(rest_internal::HttpHeader{}));
  auto actual = mock.AuthenticationHeaders(now, "my-endpoint");
  EXPECT_THAT(actual, IsOkAndHolds(Contains(rest_internal::HttpHeader(
                          "authorization", "Bearer test-token"))));
}

TEST(Credentials, AuthenticationHeaderError) {
  MockCredentials mock;
  EXPECT_CALL(mock, GetToken).WillOnce(Return(UnavailableError("try-again")));
  auto actual = mock.AuthenticationHeaders(std::chrono::system_clock::now(),
                                           "my-endpoint");
  EXPECT_EQ(actual.status(), UnavailableError("try-again"));
}

TEST(Credentials, AuthenticationHeaderEmpty) {
  MockCredentials mock;
  EXPECT_CALL(mock, GetToken)
      .WillOnce(Return(AccessToken{"", std::chrono::system_clock::now()}));
  EXPECT_CALL(mock, AllowedLocations)
      .WillOnce(Return(rest_internal::HttpHeader()));
  auto actual = mock.AuthenticationHeaders(std::chrono::system_clock::now(),
                                           "my-endpoint");
  EXPECT_THAT(actual, IsOkAndHolds(std::vector<rest_internal::HttpHeader>{}));
}

TEST(Credentials, ProjectId) {
  MockCredentials mock;
  EXPECT_THAT(mock.project_id(), Not(IsOk()));
  EXPECT_THAT(mock.project_id({}), Not(IsOk()));
}

TEST(Credentials, AllowedLocationsSuccess) {
  MockCredentials mock;
  auto const now = std::chrono::system_clock::now();
  auto const expiration = now + std::chrono::seconds(3600);
  EXPECT_CALL(mock, GetToken)
      .WillOnce(Return(AccessToken{"test-token", expiration}));
  EXPECT_CALL(mock, AllowedLocations)
      .WillOnce(Return(
          rest_internal::HttpHeader("x-allowed-locations", "my-location")));

  auto auth_headers = mock.AuthenticationHeaders(
      std::chrono::system_clock::now(), "my-endpoint");
  EXPECT_THAT(
      auth_headers,
      IsOkAndHolds(::testing::ElementsAre(
          rest_internal::HttpHeader("authorization", "Bearer test-token"),
          rest_internal::HttpHeader("x-allowed-locations", "my-location"))));
}

TEST(Credentials, AllowedLocationsFailure) {
  MockCredentials mock;
  auto const now = std::chrono::system_clock::now();
  auto const expiration = now + std::chrono::seconds(3600);
  EXPECT_CALL(mock, GetToken)
      .WillOnce(Return(AccessToken{"test-token", expiration}));
  EXPECT_CALL(mock, AllowedLocations)
      .WillOnce(Return(internal::DeadlineExceededError("RPC took too long")));

  auto auth_headers = mock.AuthenticationHeaders(
      std::chrono::system_clock::now(), "my-endpoint");
  EXPECT_THAT(auth_headers,
              IsOkAndHolds(::testing::ElementsAre(rest_internal::HttpHeader(
                  "authorization", "Bearer test-token"))));
}

}  // namespace
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace oauth2_internal
}  // namespace cloud
}  // namespace google
